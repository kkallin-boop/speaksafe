"""Tambahan backend: jadwal sosialisasi dan SOP yang dikelola PPKPT.

Dipasang dari app.py lewat 2 baris (lihat petunjuk). File ini TIDAK menyentuh
tabel laporan/komentar, jadi aturan anonim di app.py tetap utuh.
Hanya akun role 'ppkpt' yang boleh mengubah; semua akun yang login boleh membaca.
"""
import json
import os
import re
import sqlite3
from datetime import datetime, timezone

from flask import Blueprint, jsonify, request, session

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE, "speaksafe.db"))
bp = Blueprint("extra", __name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tgl TEXT NOT NULL,
  jam TEXT NOT NULL DEFAULT '',
  judul TEXT NOT NULL,
  lokasi TEXT NOT NULL DEFAULT '',
  tema TEXT NOT NULL DEFAULT '',
  pembicara TEXT NOT NULL DEFAULT '',
  poster TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sop(
  id INTEGER PRIMARY KEY CHECK (id = 1),
  steps TEXT NOT NULL,
  link TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL
);
"""
DEFAULT_STEPS = [
    {"judul": "Lapor", "isi": "anonim atau dengan identitas"},
    {"judul": "Diterima", "isi": "PPKPT meninjau laporan"},
    {"judul": "Tindak lanjut", "isi": "sesuai prosedur kampus"},
    {"judul": "Selesai", "isi": "status diperbarui"},
]
JAM = re.compile(r"^([01]?\d|2[0-3])[.:][0-5]\d$")

_c = sqlite3.connect(DB_PATH)
_c.executescript(SCHEMA)
# database lama (tabel events versi awal) ditambah kolom baru secara otomatis
_cols = {r[1] for r in _c.execute("PRAGMA table_info(events)")}
for _k in ("lokasi", "tema", "pembicara", "poster"):
    if _k not in _cols:
        _c.execute(f"ALTER TABLE events ADD COLUMN {_k} TEXT NOT NULL DEFAULT ''")
_c.commit()
_c.close()
EVCOLS = "id, tgl, jam, judul, lokasi, tema, pembicara, poster"


def _con():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    return con


def _err(msg, code):
    return jsonify(error=msg), code


def _role(con):
    uid = session.get("uid")
    if not uid:
        return None
    row = con.execute("SELECT role FROM users WHERE id=?", (uid,)).fetchone()
    return row["role"] if row else None


def _txt(v, n):
    return v.strip()[:n] if isinstance(v, str) else ""


def _event_data(d):
    judul, tgl, jam = _txt(d.get("judul"), 120), _txt(d.get("tgl"), 10), _txt(d.get("jam"), 5)
    lokasi, tema = _txt(d.get("lokasi"), 120), _txt(d.get("tema"), 200)
    pembicara, poster = _txt(d.get("pembicara"), 150), _txt(d.get("poster"), 300)
    if not judul or not tgl:
        return None, "Nama acara dan tanggal wajib diisi."
    try:
        datetime.strptime(tgl, "%Y-%m-%d")
    except ValueError:
        return None, "Format tanggal tidak valid."
    if jam and not JAM.match(jam):
        return None, "Format jam tidak valid."
    if poster and not re.match(r"^https?://", poster, re.I):
        return None, "Tautan poster harus diawali http:// atau https://."
    return (tgl, jam.replace(":", "."), judul, lokasi, tema, pembicara, poster), None


@bp.get("/api/events")
def events_list():
    con = _con()
    try:
        if not _role(con):
            return _err("Sesi berakhir. Silakan login lagi.", 401)
        rows = con.execute(f"SELECT {EVCOLS} FROM events ORDER BY tgl, jam, id").fetchall()
        return jsonify(events=[dict(r) for r in rows])
    finally:
        con.close()


@bp.post("/api/ppkpt/events")
def event_add():
    con = _con()
    try:
        role = _role(con)
        if not role:
            return _err("Sesi berakhir. Silakan login lagi.", 401)
        if role != "ppkpt":
            return _err("Akses khusus PPKPT.", 403)
        data, e = _event_data(request.get_json(silent=True) or {})
        if e:
            return _err(e, 400)
        cur = con.execute(
            "INSERT INTO events(tgl,jam,judul,lokasi,tema,pembicara,poster,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (*data, datetime.now(timezone.utc).isoformat(timespec="seconds")),
        )
        con.commit()
        keys = ("tgl", "jam", "judul", "lokasi", "tema", "pembicara", "poster")
        return jsonify(event={"id": cur.lastrowid, **dict(zip(keys, data))}), 201
    finally:
        con.close()


@bp.post("/api/ppkpt/events/<int:eid>")
def event_edit(eid):
    con = _con()
    try:
        role = _role(con)
        if not role:
            return _err("Sesi berakhir. Silakan login lagi.", 401)
        if role != "ppkpt":
            return _err("Akses khusus PPKPT.", 403)
        data, e = _event_data(request.get_json(silent=True) or {})
        if e:
            return _err(e, 400)
        cur = con.execute("UPDATE events SET tgl=?, jam=?, judul=?, lokasi=?, tema=?, pembicara=?, poster=? WHERE id=?", (*data, eid))
        con.commit()
        if not cur.rowcount:
            return _err("Jadwal tidak ditemukan.", 404)
        return jsonify(ok=True)
    finally:
        con.close()


@bp.delete("/api/ppkpt/events/<int:eid>")
def event_delete(eid):
    con = _con()
    try:
        role = _role(con)
        if not role:
            return _err("Sesi berakhir. Silakan login lagi.", 401)
        if role != "ppkpt":
            return _err("Akses khusus PPKPT.", 403)
        con.execute("DELETE FROM events WHERE id=?", (eid,))
        con.commit()
        return jsonify(ok=True)
    finally:
        con.close()


@bp.get("/api/sop")
def sop_get():
    con = _con()
    try:
        if not _role(con):
            return _err("Sesi berakhir. Silakan login lagi.", 401)
        row = con.execute("SELECT steps, link FROM sop WHERE id=1").fetchone()
        if not row:
            return jsonify(steps=DEFAULT_STEPS, link="")
        return jsonify(steps=json.loads(row["steps"]), link=row["link"])
    finally:
        con.close()


@bp.post("/api/ppkpt/sop")
def sop_set():
    con = _con()
    try:
        role = _role(con)
        if not role:
            return _err("Sesi berakhir. Silakan login lagi.", 401)
        if role != "ppkpt":
            return _err("Akses khusus PPKPT.", 403)
        d = request.get_json(silent=True) or {}
        raw = d.get("steps")
        if not isinstance(raw, list) or not 1 <= len(raw) <= 8:
            return _err("Isi 1 sampai 8 langkah SOP.", 400)
        steps = []
        for s in raw:
            s = s if isinstance(s, dict) else {}
            judul, isi = _txt(s.get("judul"), 60), _txt(s.get("isi"), 200)
            if not judul:
                return _err("Setiap langkah harus punya judul.", 400)
            steps.append({"judul": judul, "isi": isi})
        link = _txt(d.get("link"), 300)
        if link and not re.match(r"^https?://", link, re.I):
            return _err("Tautan harus diawali http:// atau https://.", 400)
        con.execute(
            "INSERT INTO sop(id,steps,link,updated_at) VALUES(1,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET steps=excluded.steps, link=excluded.link, updated_at=excluded.updated_at",
            (json.dumps(steps, ensure_ascii=False), link, datetime.now(timezone.utc).isoformat(timespec="seconds")),
        )
        con.commit()
        return jsonify(ok=True)
    finally:
        con.close()
