@echo off
cd /d "%~dp0"
call venv\Scripts\activate
python buat_akun_ppkpt.py
pause
