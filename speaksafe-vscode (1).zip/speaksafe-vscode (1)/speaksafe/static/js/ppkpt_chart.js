/* Beranda PPKPT: donut chart status laporan.
   Dipanggil dari show("pdash") di app.js. Memakai pr (daftar laporan PPKPT) dan STAGES dari app.js. */
const SCOL = ["var(--s1)", "var(--s2)", "var(--s3)"];
function renderPdash() {
  const n = [1, 2, 3].map((s) => pr.filter((r) => r.stage === s).length),
    total = n.reduce((a, b) => a + b, 0),
    R = 72,
    C = 2 * Math.PI * R,
    gap = n.filter((v) => v > 0).length > 1 ? 3 : 0;
  let off = 0,
    arcs = "";
  n.forEach((v, i) => {
    if (!v) return;
    const len = (v / total) * C;
    arcs += `<circle cx="100" cy="100" r="${R}" fill="none" stroke="${SCOL[i]}" stroke-width="28" stroke-dasharray="${Math.max(len - gap, 0.1)} ${C}" stroke-dashoffset="${-off}" transform="rotate(-90 100 100)"><title>${STAGES[i]}: ${v}</title></circle>`;
    off += len;
  });
  const label = STAGES.map((s, i) => `${s} ${n[i]}`).join(", ");
  $("#pDonut").innerHTML =
    `<svg viewBox="0 0 200 200" role="img" aria-label="Grafik status laporan. ${label}.">` +
    `<circle class="trk" cx="100" cy="100" r="${R}" fill="none" stroke-width="28"/>${arcs}` +
    `<text class="ctot" x="100" y="106" text-anchor="middle">${total}</text>` +
    `<text class="clbl" x="100" y="128" text-anchor="middle">laporan</text></svg>`;
  $("#pLegend").innerHTML =
    STAGES.map(
      (s, i) =>
        `<div class="lgr"><i style="background:${SCOL[i]}"></i><span>${s}</span><b>${n[i]}</b><small>${total ? Math.round((n[i] / total) * 100) : 0}%</small></div>`,
    ).join("") +
    (total ? "" : '<div style="color:var(--mut);font-size:14px;margin-top:8px">Belum ada laporan masuk.</div>');
}
