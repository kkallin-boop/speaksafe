const SOP_PDF = "/static/sop-ppkpt.pdf";
const $ = (s) => document.querySelector(s),
  $$ = (s) => [...document.querySelectorAll(s)];
const esc = (s) =>
  String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
const STAGES = ["Laporan terkirim", "Laporan diterima", "Selesai ditindak"];
const ITSB = /^[^@\s]+@([a-z0-9-]+\.)*itsb\.ac\.id$/;
let user = null,
  reports = [],
  sel = null,
  pending = null,
  cv = "login",
  stack = [];
const L = async (fn, ms = 700) => {
  $("#ld").classList.remove("hide");
  try {
    await Promise.all([fn(), new Promise((r) => setTimeout(r, ms))]);
  } catch (e) {
    console.error(e);
  } finally {
    $("#ld").classList.add("hide");
  }
};
async function api(path, method = "GET", body) {
  const o = { method, credentials: "same-origin", headers: {} };
  if (method !== "GET") {
    o.headers["Content-Type"] = "application/json";
    o.body = JSON.stringify(body || {});
  }
  let r;
  try {
    r = await fetch(path, o);
  } catch (e) {
    return { ok: false, status: 0, data: { error: "Tidak dapat terhubung ke server." } };
  }
  let d = {};
  try {
    d = await r.json();
  } catch (e) {}
  return { ok: r.ok, status: r.status, data: d };
}
async function loadReports() {
  const r = await api("/api/reports");
  if (r.ok) reports = r.data.reports;
  else if (r.status === 401) expire();
  return r.ok;
}
function expire() {
  user = null;
  reports = [];
  sel = null;
  stack = [];
  show("login");
  openAcc("login");
  $("#loginErr").textContent = "Sesi berakhir. Silakan login lagi.";
}
const EYE =
  '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>';
$$(".pw").forEach((w) => {
  const i = w.querySelector("input"),
    b = document.createElement("button");
  b.type = "button";
  b.className = "eye";
  b.setAttribute("aria-label", "Tampilkan password");
  b.innerHTML = EYE + "</svg>";
  b.onclick = () => {
    const h = i.type === "password";
    i.type = h ? "text" : "password";
    b.innerHTML = EYE + (h ? '<path d="M3 3l18 18"/>' : "") + "</svg>";
    b.setAttribute("aria-label", h ? "Sembunyikan password" : "Tampilkan password");
  };
  w.appendChild(b);
});

function show(v) {
  cv = v;
  ["login", "home", "report", "done", "reports", "ppkpt"].forEach((x) =>
    $("#v-" + x).classList.toggle("hide", x !== v),
  );
  $("#menu").classList.toggle("hide", !user);
  document.body.classList.toggle("lg", v === "login");
  document.body.classList.toggle("fit", v === "ppkpt" && ptab === "dash");
  $$("#menu [data-v]").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
  if (v === "home") renderHome();
  const role = user && user.role === "ppkpt" ? "ppkpt" : "mhs";
  $$("#menu [data-role]").forEach((b) => b.classList.toggle("hide", b.dataset.role !== role));
  if (v === "reports") renderReports();
  if (v === "ppkpt") renderPpkpt();
  window.scrollTo(0, 0);
}
function go(v) {
  if (v === "home") stack = [];
  else if (cv !== "done" && cv !== v) stack.push(cv);
  show(v);
}
async function nav(v) {
  if (user && (v === "home" || v === "reports")) await loadReports();
  if (user && v === "ppkpt") await loadPpkpt();
  if (user) go(v);
}
function modal(html, btns, wide) {
  $("#mb").innerHTML = html;
  $("#mf").innerHTML = "";
  $("#box").classList.toggle("wide", !!wide);
  btns.forEach((b) => {
    const e = document.createElement("button");
    e.className = "btn " + (b.g ? "ghost" : "");
    e.textContent = b.t;
    e.onclick = b.fn;
    $("#mf").appendChild(e);
  });
  $("#mdl").classList.remove("hide");
}
const closeM = () => $("#mdl").classList.add("hide");
$("#mback").onclick = () => L(closeM, 300);

let EVS = [],
  SOPD = null,
  selEv = null;
const DEF_STEPS = [
  { judul: "Lapor", isi: "anonim atau dengan identitas" },
  { judul: "Diterima", isi: "PPKPT meninjau laporan" },
  { judul: "Tindak lanjut", isi: "sesuai prosedur kampus" },
  { judul: "Selesai", isi: "status diperbarui" },
];
async function loadJadwal() {
  const r = await api("/api/events");
  EVS = r.ok ? r.data.events : [];
}
async function loadSop() {
  const r = await api("/api/sop");
  SOPD = r.ok ? r.data : null;
}
const B = { y: new Date().getFullYear(), m: new Date().getMonth() };
let cy = B.y,
  cm = B.m;
function evDetail(e) {
  const row = (k, v) => (v ? `<div class="evd"><small>${k}</small><span>${esc(v)}</span></div>` : "");
  const link = /^https?:\/\//i.test(e.poster || "")
    ? `<div style="margin-top:14px"><a class="btn sm" href="${esc(e.poster)}" target="_blank" rel="noopener">Download poster</a></div>`
    : "";
  return (
    `<button class="evback" data-evback>← Semua jadwal</button><h3 style="font-size:21px;margin:8px 0 6px">${esc(e.judul)}</h3>` +
    row("Tanggal", fmtTgl(e.tgl)) +
    row("Jam", e.jam ? e.jam + " WIB" : "") +
    row("Lokasi", e.lokasi) +
    row("Tema", e.tema) +
    row("Pembicara", e.pembicara) +
    link
  );
}
function calHTML() {
  const ym = cy + "-" + String(cm + 1).padStart(2, "0");
  const evo = EVS.filter((e) => e.tgl.startsWith(ym)),
    ev = evo.map((e) => [+e.tgl.slice(8, 10), e.judul, e.jam, e.id, e.lokasi]),
    set = new Set(ev.map((e) => e[0]));
  const cur = EVS.find((e) => e.id === selEv && e.tgl.startsWith(ym));
  const first = (new Date(cy, cm, 1).getDay() + 6) % 7,
    days = new Date(cy, cm + 1, 0).getDate();
  let g = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"].map((d) => `<b>${d}</b>`).join("");
  for (let i = 0; i < first; i++) g += '<span class="e"></span>';
  for (let d = 1; d <= days; d++)
    g += set.has(d) ? `<span class="ev" data-d="${d}" tabindex="0">${d}</span>` : `<span>${d}</span>`;
  const mon = new Date(cy, cm, 1).toLocaleDateString("id-ID", { month: "long", year: "numeric" });
  const side = ev.length
    ? ev
        .map(
          (e) =>
            `<div class="sli" data-d="${e[0]}" data-eid="${e[3]}" tabindex="0" role="button"><b>${e[0]}</b><span>${esc(e[1])}${e[2] || e[4] ? `<small>${[e[2] ? esc(e[2]) + " WIB" : "", esc(e[4] || "")].filter(Boolean).join(" · ")}</small>` : ""}</span></div>`,
        )
        .join("")
    : '<div style="color:var(--mut);font-size:14px">Belum ada jadwal bulan ini.</div>';
  return `<div><div class="calh"><button data-cal="-1" aria-label="Bulan sebelumnya">‹</button><span>${mon}</span><button data-cal="1" aria-label="Bulan berikutnya">›</button></div><div class="cal">${g}</div></div><div><div class="leg"><i></i>Tanggal hijau = ada jadwal</div>${cur ? evDetail(cur) : `<h3 style="font-size:19px">Jadwal tersedia</h3>${side}<div class="leg" style="margin-top:10px">Klik jadwal untuk melihat detail</div>`}</div>`;
}
function sopHtml() {
  const st = SOPD && SOPD.steps && SOPD.steps.length ? SOPD.steps : DEF_STEPS;
  const steps = st
    .map((s, i) => `<div><i>${i + 1}</i><span><b>${esc(s.judul)}</b>${s.isi ? " · " + esc(s.isi) : ""}</span></div>`)
    .join("");
  return (
    '<h2>Panduan <em>SOP PPKPT</em></h2><div class="pdf"><div class="pi">PDF</div><div><b>SOP PPKPT ITSB</b><small>Dokumen resmi</small></div><div class="pb"><button class="btn sm" data-pdf="open">Buka</button><button class="btn sm ghost" data-pdf="dl">Download</button></div></div><div id="pdfNote" class="opt" style="font-size:13px;margin-top:8px"></div><div class="sum">' +
    steps +
    "</div>"
  );
}

document.addEventListener("click", (e) => {
  const g = e.target.closest("[data-go]");
  if (g) {
    e.preventDefault();
    L(() => nav(g.dataset.go), 500);
    return;
  }
  const m = e.target.closest("#menu [data-v]");
  if (m) {
    L(() => nav(m.dataset.v), 500);
    return;
  }
  const o = e.target.closest("[data-open]");
  if (o) {
    L(async () => {
      sel = o.dataset.open;
      await nav("reports");
    }, 500);
    return;
  }
  if (e.target.closest("[data-back]")) {
    L(async () => {
      const p = stack.pop() || "home";
      if (user && (p === "home" || p === "reports")) await loadReports();
      if (user) show(p);
    }, 400);
    return;
  }
  const eb = e.target.closest("[data-evback]");
  if (eb) {
    selEv = null;
    $("#calBox").innerHTML = calHTML();
    return;
  }
  const se = e.target.closest(".sli[data-eid]");
  if (se) {
    selEv = +se.dataset.eid;
    $("#calBox").innerHTML = calHTML();
    return;
  }
  const c = e.target.closest("[data-cal]");
  if (c) {
    L(() => {
      selEv = null;
      cm += +c.dataset.cal;
      if (cm < 0) {
        cm = 11;
        cy--;
      }
      if (cm > 11) {
        cm = 0;
        cy++;
      }
      $("#calBox").innerHTML = calHTML();
    }, 300);
    return;
  }
  const d = e.target.closest(".cal .ev");
  if (d) {
    const ym = cy + "-" + String(cm + 1).padStart(2, "0") + "-" + d.dataset.d.padStart(2, "0");
    const day = EVS.filter((x) => x.tgl === ym);
    if (day.length === 1) {
      selEv = day[0].id;
      $("#calBox").innerHTML = calHTML();
    } else {
      selEv = null;
      $("#calBox").innerHTML = calHTML();
      $$(".sli").forEach((x) => x.classList.toggle("on", x.dataset.d === d.dataset.d));
    }
    return;
  }
  const p = e.target.closest("[data-pdf]");
  if (p) {
    (async () => {
      if (SOPD && SOPD.link) {
        window.open(SOPD.link, "_blank", "noopener");
        return;
      }
      let ok = false;
      try {
        ok = (await fetch(SOP_PDF, { method: "HEAD" })).ok;
      } catch (_) {}
      if (!ok) {
        $("#pdfNote").textContent =
          "File PDF resmi belum diunggah. Taruh file di folder static dengan nama sop-ppkpt.pdf.";
        return;
      }
      if (p.dataset.pdf === "open") window.open(SOP_PDF, "_blank");
      else {
        const a = document.createElement("a");
        a.href = SOP_PDF;
        a.download = "SOP-PPKPT-ITSB.pdf";
        document.body.appendChild(a);
        a.click();
        a.remove();
      }
    })();
    return;
  }
  const a = e.target.closest("[data-act]");
  if (a) {
    const k = a.dataset.act;
    L(async () => {
      if (k === "jadwal") {
        await loadJadwal();
        selEv = null;
        cy = B.y;
        cm = B.m;
        modal(
          '<h2>Jadwal <em>sosialisasi</em></h2><p style="color:var(--mut);margin:4px 0 0;font-size:14px">Jadwal resmi dari PPKPT ITSB.</p><div class="cg" id="calBox">' +
            calHTML() +
            "</div>",
          [],
          true,
        );
      }
      if (k === "sop") {
        await loadSop();
        modal(sopHtml(), []);
      }
    }, 500);
  }
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.dataset && (e.target.dataset.act || e.target.dataset.go || e.target.dataset.eid))
    e.target.click();
  if (e.key === "Enter" && e.target.id === "pw") $("#loginBtn").click();
  if (e.key === "Enter" && e.target.id === "rc") $("#regBtn").click();
});
$("#devBtn").onclick = () => $("#dp").classList.toggle("hide");

function openAcc(which) {
  $("#aLogin").classList.toggle("on", which === "login");
  $("#aReg").classList.toggle("on", which === "reg");
  $("#loginErr").textContent = $("#regErr").textContent = $("#loginOk").textContent = "";
}
$("#aLogin .h").onclick = () => L(() => openAcc($("#aLogin").classList.contains("on") ? "" : "login"), 350);
$("#aReg .h").onclick = () => L(() => openAcc($("#aReg").classList.contains("on") ? "" : "reg"), 350);
let tmr;
$("#re").oninput = () => {
  clearTimeout(tmr);
  const e = $("#re").value.trim().toLowerCase();
  if (!ITSB.test(e)) {
    $("#regErr").textContent = "";
    return;
  }
  tmr = setTimeout(async () => {
    const r = await api("/api/check-email?email=" + encodeURIComponent(e));
    if ($("#re").value.trim().toLowerCase() === e)
      $("#regErr").textContent = r.ok && r.data.exists ? "Email ini sudah terdaftar." : "";
  }, 350);
};
$("#regBtn").onclick = () => {
  const n = $("#rn").value.trim(),
    e = $("#re").value.trim().toLowerCase(),
    p = $("#rp").value,
    c = $("#rc").value,
    er = $("#regErr");
  if (!n || !e || !p || !c) {
    er.textContent = "Semua kolom wajib diisi.";
    return;
  }
  if (!ITSB.test(e)) {
    er.textContent = "Gunakan email kampus ITSB (@itsb.ac.id).";
    return;
  }
  if (p.length < 8) {
    er.textContent = "Password minimal 8 karakter.";
    return;
  }
  if (p !== c) {
    er.textContent = "Konfirmasi password tidak sama.";
    return;
  }
  er.textContent = "";
  L(async () => {
    const r = await api("/api/register", "POST", { name: n, email: e, password: p });
    if (!r.ok) {
      er.textContent = r.data.error || "Registrasi gagal.";
      return;
    }
    ["rn", "re", "rp", "rc"].forEach((i) => ($("#" + i).value = ""));
    openAcc("login");
    $("#em").value = e;
    $("#pw").value = "";
    $("#loginOk").textContent = "Registrasi berhasil. Silakan login.";
  }, 1000);
};
$("#loginBtn").onclick = () => {
  const e = $("#em").value.trim().toLowerCase(),
    p = $("#pw").value,
    er = $("#loginErr");
  $("#loginOk").textContent = "";
  if (!e || !p) {
    er.textContent = "Email dan password wajib diisi.";
    return;
  }
  er.textContent = "";
  L(async () => {
    const r = await api("/api/login", "POST", { email: e, password: p });
    if (!r.ok) {
      er.textContent = r.data.error || "Login gagal.";
      return;
    }
    user = r.data.user;
    $("#pw").value = "";
    await landing();
  }, 900);
};
async function doLogout() {
  await api("/api/logout", "POST");
  user = null;
  reports = [];
  sel = null;
  stack = [];
  openAcc("");
  show("login");
}
$("#out").onclick = () => {
  const warn =
    cv === "report"
      ? '<p style="color:var(--mut);margin:10px 0 0;font-size:14px"><b>Perhatian:</b> isian laporan yang belum dikirim tidak akan tersimpan.</p>'
      : "";
  modal(
    '<h2>Yakin ingin <em>keluar</em>?</h2><p style="color:var(--mut);margin:8px 0 0">Kamu perlu login lagi untuk masuk kembali ke SpeakSafe ITSB.</p>' +
      warn,
    [
      { t: "Batal", g: 1, fn: closeM },
      {
        t: "Ya, keluar",
        fn: () => {
          closeM();
          L(doLogout, 600);
        },
      },
    ],
  );
};

$("#jenis").onchange = () => {
  const o = $("#jenis").value === "Lainnya";
  $("#lain").classList.toggle("hide", !o);
  if (o) $("#lain").focus();
};
$("#sendBtn").onclick = () => {
  const k = $("#kron").value.trim(),
    l = $("#lok").value.trim(),
    t = $("#tgl").value,
    er = $("#repErr");
  if (!k || !l || !t) {
    er.textContent = "Tanggal, lokasi, dan kronologi wajib diisi.";
    return;
  }
  const lain = $("#lain").value.trim();
  if ($("#jenis").value === "Lainnya" && !lain) {
    er.textContent = "Isi jenis bullying lainnya pada kotak yang tersedia.";
    return;
  }
  er.textContent = "";
  const anon = document.querySelector("input[name=idt]:checked").value === "anon";
  pending = {
    anon,
    jenis: $("#jenis").value === "Lainnya" ? "Lainnya – " + lain : $("#jenis").value,
    tgl: t,
    lok: l,
    kron: k,
    ket: $("#ket").value.trim(),
  };
  L(() => {
    const body = anon
      ? '<h2>Yakin laporkan <em>dengan anonim</em>?</h2><p style="color:var(--mut)">Identitasmu tidak akan ditampilkan. PPKPT hanya melihat laporan ini sebagai <b>Pelapor anonim</b>.</p>'
      : '<h2>Yakin laporkan <em>dengan identitas</em>?</h2><p style="color:var(--mut)">Nama dan email berikut akan muncul di tampilan PPKPT:</p><div class="id"><b>Nama</b>' +
        esc(user.name) +
        '</div><div class="id"><b>Email</b>' +
        esc(user.email) +
        "</div>";
    modal(body, [
      { t: "Batal", g: 1, fn: closeM },
      {
        t: "Ya, kirim laporan",
        fn: () => {
          closeM();
          L(submit, 1000);
        },
      },
    ]);
  }, 500);
};
async function submit() {
  const r = await api("/api/reports", "POST", pending);
  if (!r.ok) {
    if (r.status === 401) return expire();
    $("#repErr").textContent = r.data.error || "Gagal mengirim laporan. Coba lagi.";
    return;
  }
  const rep = r.data.report;
  reports.unshift(rep);
  sel = rep.no;
  pending = null;
  $("#doneNum").textContent = rep.no;
  ["kron", "lok", "tgl", "ket", "lain"].forEach((i) => ($("#" + i).value = ""));
  $("#lain").classList.add("hide");
  $("#jenis").selectedIndex = 0;
  stack = [];
  show("done");
}
const cur = () => reports.find((r) => r.no === sel);
function renderHome() {
  $("#hList").innerHTML = reports.length
    ? reports
        .slice(0, 3)
        .map(
          (r) =>
            `<div class="hrow" data-open="${r.no}"><span><b>${r.no}</b> · ${esc(r.jenis.split(" ")[0])}</span><span class="tag">${STAGES[r.stage - 1]}</span></div>`,
        )
        .join("")
    : '<div style="color:var(--mut);font-size:14px;margin-top:10px">Belum ada laporan.</div>';
}
function renderReports() {
  $("#noRep").classList.toggle("hide", reports.length > 0);
  $("#list").innerHTML = reports
    .map(
      (r) =>
        `<button class="item ${r.no === sel ? "on" : ""}" data-no="${r.no}"><span><b>${r.no}</b><small>${esc(r.jenis)} · ${esc(r.tgl)}</small></span><span class="tag">${STAGES[r.stage - 1]}</span></button>`,
    )
    .join("");
  $$("#list .item").forEach(
    (b) =>
      (b.onclick = () =>
        L(() => {
          sel = b.dataset.no;
          renderReports();
        }, 500)),
  );
  const r = cur();
  $("#detail").classList.toggle("hide", !r);
  if (!r) return;
  $("#tNum").textContent = r.no;
  $("#tTag").textContent = r.anon ? "Anonim" : "Dengan identitas";
  $("#tInfo").innerHTML = esc(r.jenis) + " · " + esc(r.lok) + (r.ket ? "<br>Keterangan: " + esc(r.ket) : "");
  $("#tl").innerHTML = STAGES.map(
    (n, i) =>
      `<li class="${i < r.stage ? "done" : i === r.stage ? "cur" : ""}"><span class="dot">${i < r.stage ? "✓" : ""}</span><span>${n}</span></li>`,
  ).join("");
  $("#cms").innerHTML = r.cms.length
    ? r.cms
        .map(
          (c) =>
            `<div class="cm ${c.me ? "me" : ""}"><small>${c.me ? "Kamu" : "PPKPT"}</small>${esc(c.t)}</div>`,
        )
        .join("")
    : '<span style="color:var(--mut);font-size:14px">Belum ada komentar.</span>';
}
$("#cbtn").onclick = () => {
  const r = cur(),
    v = $("#cin").value.trim();
  if (!v) return;
  L(async () => {
    const x = await api("/api/reports/" + encodeURIComponent(r.no) + "/comments", "POST", { text: v });
    if (x.ok) {
      r.cms.push(x.data.comment);
      $("#cin").value = "";
      renderReports();
    } else if (x.status === 401) expire();
  }, 600);
};
/* ===== PPKPT ===== */
let pr = [],
  psel = null,
  ptab = "dash",
  pdemo = false;
async function landing() {
  if (user.role === "ppkpt") {
    await loadPpkpt();
    ptab = "dash";
    go("ppkpt");
  } else {
    await loadReports();
    go("home");
  }
}
async function loadPpkpt() {
  const r = await api("/api/ppkpt/reports");
  if (r.ok) pr = r.data.reports;
  else if (r.status === 401) expire();
  return r.ok;
}
const pcur = () => pr.find((r) => r.no === psel);
const PCOL = ["#59692f", "#e27a5c", "#9aaa5e", "#d9a441", "#8a6f4d", "#6b8f8a", "#b86b77"];
const MON = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
const jenisKey = (j) => String(j).split(" – ")[0].replace(/\s*\(.*$/, "").trim();
const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
/* data contoh (hanya untuk simulasi tampilan, tidak masuk database) */
const DEMO = (() => {
  const y = new Date().getFullYear(),
    mnow = new Date().getMonth();
  const w = [["Verbal", 30], ["Siber", 24], ["Fisik", 12], ["Pengucilan sosial", 14], ["Pelecehan", 12], ["Lainnya", 8]];
  let s = 11;
  const rnd = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const pick = () => {
    let t = rnd() * 100;
    for (const [k, v] of w) if ((t -= v) < 0) return k;
    return "Lainnya";
  };
  return Array.from({ length: 42 }, () => {
    const m = Math.floor(rnd() * (mnow + 1)),
      age = mnow - m;
    const stage = rnd() < Math.min(0.9, 0.3 + age * 0.12) ? 3 : rnd() < 0.5 ? 2 : 1;
    return { jenis: pick(), stage, dibuat: new Date(y, m, 10).toISOString() };
  });
})();
function renderPpkpt() {
  $$(".ptabs [data-ptab]").forEach((b) => b.classList.toggle("on", b.dataset.ptab === ptab));
  ["dash", "inbox", "jsop"].forEach((t) => $("#pt-" + t).classList.toggle("hide", t !== ptab));
  document.body.classList.toggle("fit", cv === "ppkpt" && ptab === "dash");
  $("#pBadge").textContent = pr.filter((r) => r.stage === 1).length;
  renderDash();
  renderInbox();
  if (ptab === "jsop") renderJsop();
}
function renderDash() {
  const y = new Date().getFullYear();
  const d = pdemo ? DEMO : pr.filter((r) => new Date(r.dibuat).getFullYear() === y);
  const n = d.length,
    c = [0, 1, 2, 3].map((s) => d.filter((r) => r.stage === s).length);
  $("#dYear").textContent = y;
  $("#dDemo").classList.toggle("hide", !pdemo);
  $("#dDemoBtn").textContent = pdemo ? "Pakai data asli" : "Lihat data contoh";
  $("#dTot").textContent = n;
  $("#dN1").textContent = c[1];
  $("#dN2").textContent = c[2];
  $("#dN3").textContent = c[3];
  $("#dP3").textContent = pct(c[3], n) + "% dari total";
  const empty =
    '<div style="color:var(--mut);font-size:14px;margin-top:14px">Belum ada laporan tahun ini. Klik "Lihat data contoh" untuk melihat simulasi tampilan.</div>';

  /* grafik donat: jenis kasus */
  if (!n) $("#dJenis").innerHTML = empty;
  else {
    const by = {};
    d.forEach((r) => {
      const k = jenisKey(r.jenis);
      by[k] = by[k] || { n: 0, s: 0 };
      by[k].n++;
      if (r.stage === 3) by[k].s++;
    });
    const rows = Object.entries(by).sort((a, b) => b[1].n - a[1].n);
    let off = 25,
      seg = "";
    rows.forEach(([, v], i) => {
      const p = (v.n / n) * 100;
      seg += `<circle cx="21" cy="21" r="15.9155" fill="none" stroke="${PCOL[i % PCOL.length]}" stroke-width="6" stroke-dasharray="${p} ${100 - p}" stroke-dashoffset="${off}"/>`;
      off -= p;
    });
    const donut = `<svg viewBox="0 0 42 42" class="donut" role="img" aria-label="Persentase jenis kasus"><circle cx="21" cy="21" r="15.9155" fill="none" stroke="var(--line)" stroke-width="6"/>${seg}<text x="21" y="22.2" text-anchor="middle" class="dn">${n}</text><text x="21" y="26.6" text-anchor="middle" class="ds">laporan</text></svg>`;
    const leg = rows
      .map(
        ([k, v], i) =>
          `<div class="lg2"><i style="background:${PCOL[i % PCOL.length]}"></i><b>${esc(k)}</b><span class="mu">${v.n} (${pct(v.n, n)}%)</span><span class="tag s3" title="${v.s} dari ${v.n} selesai">${pct(v.s, v.n)}% selesai</span></div>`,
      )
      .join("");
    $("#dJenis").innerHTML = `<div class="donutw">${donut}<div class="lgs">${leg}</div></div>`;
  }

  /* grafik batang: laporan per bulan */
  if (!n) $("#dBulan").innerHTML = empty;
  else {
    const m = Array.from({ length: 12 }, () => ({ s: 0, o: 0 }));
    d.forEach((r) => {
      const mi = new Date(r.dibuat).getMonth();
      if (r.stage === 3) m[mi].s++;
      else m[mi].o++;
    });
    const mx = Math.ceil(Math.max(4, ...m.map((x) => x.s + x.o)) / 4) * 4;
    const W = 520,
      H = 220,
      L0 = 30,
      T0 = 14,
      B0 = 30,
      ph = H - T0 - B0,
      bw = 26,
      gap = (W - L0 - 8 - bw * 12) / 11;
    let g = "";
    for (let k = 0; k <= 4; k++) {
      const v = (mx * k) / 4,
        yy = T0 + ph - (v / mx) * ph;
      g += `<line x1="${L0}" x2="${W - 8}" y1="${yy}" y2="${yy}" class="gl"/><text x="${L0 - 6}" y="${yy + 4}" text-anchor="end" class="ax">${v}</text>`;
    }
    m.forEach((x, i) => {
      const xx = L0 + i * (bw + gap),
        hs = (x.s / mx) * ph,
        ho = (x.o / mx) * ph,
        t = x.s + x.o;
      g += `<g><title>${MON[i]}: ${x.s} selesai, ${x.o} belum selesai</title>`;
      if (x.s) g += `<rect x="${xx}" y="${T0 + ph - hs}" width="${bw}" height="${hs}" rx="4" class="b1"/>`;
      if (x.o) g += `<rect x="${xx}" y="${T0 + ph - hs - ho}" width="${bw}" height="${ho}" rx="4" class="b2"/>`;
      if (t) g += `<text x="${xx + bw / 2}" y="${T0 + ph - hs - ho - 4}" text-anchor="middle" class="ax">${t}</text>`;
      g += `<text x="${xx + bw / 2}" y="${H - 10}" text-anchor="middle" class="ax">${MON[i]}</text></g>`;
    });
    $("#dBulan").innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Laporan per bulan">${g}</svg>`;
  }
}
function renderInbox() {
  const f = +$("#pf").value;
  const list = f ? pr.filter((r) => r.stage === f) : pr;
  $("#pCount").textContent = pr.length;
  $("#pList").innerHTML = list.length
    ? list
        .map(
          (r) =>
            `<button class="item ${r.no === psel ? "on" : ""}" data-pno="${r.no}"><span><b>${r.no}</b><small>${esc(r.jenis)} · ${esc(r.tgl)} · ${r.anon ? "Anonim" : esc(r.pelapor.name)}</small></span><span class="tag s${r.stage}">${STAGES[r.stage - 1]}</span></button>`,
        )
        .join("")
    : '<div style="color:var(--mut);font-size:14px;margin-top:10px">Tidak ada laporan.</div>';
  $$("#pList .item").forEach(
    (b) =>
      (b.onclick = () =>
        L(() => {
          psel = b.dataset.pno;
          renderPpkpt();
        }, 400)),
  );
  const r = pcur();
  $("#pDetail").classList.toggle("hide", !r);
  $("#pEmpty").classList.toggle("hide", !!r);
  if (!r) return;
  $("#pNo").textContent = r.no;
  $("#pTag").textContent = r.anon ? "Anonim" : "Dengan identitas";
  $("#pWho").innerHTML = r.anon ? "Pelapor anonim" : esc(r.pelapor.name) + " · " + esc(r.pelapor.email);
  $("#pInfo").textContent = r.jenis + " · " + r.tgl + " · " + r.lok;
  $("#pKron").textContent = r.kron;
  $("#pKetW").classList.toggle("hide", !r.ket);
  $("#pKet").textContent = r.ket;
  $("#pTl").innerHTML = STAGES.map(
    (n, i) =>
      `<li class="${i < r.stage ? "done" : i === r.stage ? "cur" : ""}"><span class="dot">${i < r.stage ? "✓" : ""}</span><span>${n}</span></li>`,
  ).join("");
  $("#pAcc").disabled = r.stage >= 2;
  $("#pDone").disabled = r.stage >= 3;
  $("#pCms").innerHTML = r.cms.length
    ? r.cms
        .map(
          (c) => `<div class="cm ${c.me ? "me" : ""}"><small>${c.me ? "Kamu (PPKPT)" : "Pelapor"}</small>${esc(c.t)}</div>`,
        )
        .join("")
    : '<span style="color:var(--mut);font-size:14px">Belum ada komentar.</span>';
}
function setStatus(s) {
  const r = pcur();
  if (!r) return;
  L(async () => {
    const x = await api("/api/ppkpt/reports/" + encodeURIComponent(r.no) + "/status", "POST", { status: s });
    if (x.ok) {
      r.stage = s;
      renderPpkpt();
    } else if (x.status === 401) expire();
  }, 600);
}
$("#pAcc").onclick = () => setStatus(2);
$("#pDone").onclick = () => setStatus(3);
$("#pf").onchange = renderPpkpt;
$$("[data-ptab]").forEach(
  (b) =>
    (b.onclick = async () => {
      ptab = b.dataset.ptab;
      if (ptab === "jsop") await loadJsop();
      renderPpkpt();
      window.scrollTo(0, 0);
    }),
);
$("#dDemoBtn").onclick = () => {
  pdemo = !pdemo;
  renderDash();
};
$("#pbtn").onclick = () => {
  const r = pcur(),
    v = $("#pin").value.trim();
  if (!r || !v) return;
  L(async () => {
    const x = await api("/api/ppkpt/reports/" + encodeURIComponent(r.no) + "/comments", "POST", { text: v });
    if (x.ok) {
      r.cms.push(x.data.comment);
      $("#pin").value = "";
      renderPpkpt();
    } else if (x.status === 401) expire();
  }, 600);
};
/* --- Jadwal & SOP (dikelola PPKPT) --- */
let pev = [],
  sopDraft = [],
  pedit = null;
const fmtTgl = (t) =>
  new Date(t + "T00:00").toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
async function loadJsop() {
  const [a, b] = await Promise.all([api("/api/events"), api("/api/sop")]);
  if (a.ok) pev = a.data.events;
  else if (a.status === 401) return expire();
  if (b.ok) {
    sopDraft = b.data.steps.map((s) => ({ ...s }));
    $("#sopLink").value = b.data.link || "";
  }
}
function renderJsop() {
  $("#evList").innerHTML = pev.length
    ? pev
        .map(
          (e) =>
            `<div class="evr"><span><b>${esc(e.judul)}</b><small>${fmtTgl(e.tgl)}${e.jam ? " · " + esc(e.jam) + " WIB" : ""}${e.lokasi ? " · " + esc(e.lokasi) : ""}${e.poster ? " · ada poster" : ""}</small></span><span class="acts"><button class="btn sm ghost" data-evedit="${e.id}">Ubah</button><button class="btn sm ghost" data-evdel="${e.id}">Hapus</button></span></div>`,
        )
        .join("")
    : '<div style="color:var(--mut);font-size:14px;margin-top:12px">Belum ada jadwal. Tambahkan jadwal pertama di atas.</div>';
  $("#sopEdit").innerHTML = sopDraft
    .map(
      (s, i) =>
        `<div class="sr"><span class="no">${i + 1}</span><input data-sj="${i}" value="${esc(s.judul)}" placeholder="Judul" maxlength="60" aria-label="Judul langkah ${i + 1}"><input data-si="${i}" value="${esc(s.isi)}" placeholder="Keterangan" maxlength="200" aria-label="Keterangan langkah ${i + 1}"><button class="btn sm ghost" data-srdel="${i}" aria-label="Hapus langkah ${i + 1}">×</button></div>`,
    )
    .join("");
  $("#sopAdd").disabled = sopDraft.length >= 8;
}
function resetEv() {
  pedit = null;
  $("#evJudul").value = "";
  $("#evTgl").value = "";
  $("#evJam").value = "";
  ["evLokasi", "evPembicara", "evTema", "evPoster"].forEach((i) => ($("#" + i).value = ""));
  $("#evSave").textContent = "Tambah jadwal";
  $("#evCancel").classList.add("hide");
}
$("#evCancel").onclick = resetEv;
$("#evSave").onclick = () => {
  const body = {
    judul: $("#evJudul").value.trim(),
    tgl: $("#evTgl").value,
    jam: $("#evJam").value,
    lokasi: $("#evLokasi").value.trim(),
    pembicara: $("#evPembicara").value.trim(),
    tema: $("#evTema").value.trim(),
    poster: $("#evPoster").value.trim(),
  };
  $("#evErr").textContent = "";
  if (!body.judul || !body.tgl) {
    $("#evErr").textContent = "Nama acara dan tanggal wajib diisi.";
    return;
  }
  L(async () => {
    const x = await api(pedit ? "/api/ppkpt/events/" + pedit : "/api/ppkpt/events", "POST", body);
    if (x.ok) {
      resetEv();
      await loadJsop();
      renderJsop();
    } else if (x.status === 401) expire();
    else $("#evErr").textContent = (x.data && x.data.error) || "Gagal menyimpan jadwal.";
  }, 400);
};
$("#evList").onclick = (e) => {
  const ed = e.target.closest("[data-evedit]"),
    dl = e.target.closest("[data-evdel]");
  if (ed) {
    const v = pev.find((x) => String(x.id) === ed.dataset.evedit);
    if (!v) return;
    pedit = v.id;
    $("#evJudul").value = v.judul;
    $("#evTgl").value = v.tgl;
    $("#evJam").value = v.jam ? v.jam.replace(".", ":").padStart(5, "0") : "";
    $("#evLokasi").value = v.lokasi || "";
    $("#evPembicara").value = v.pembicara || "";
    $("#evTema").value = v.tema || "";
    $("#evPoster").value = v.poster || "";
    $("#evSave").textContent = "Simpan perubahan";
    $("#evCancel").classList.remove("hide");
    $("#evJudul").focus();
  }
  if (dl && confirm("Hapus jadwal ini?"))
    L(async () => {
      const x = await api("/api/ppkpt/events/" + dl.dataset.evdel, "DELETE");
      if (x.ok) {
        if (String(pedit) === dl.dataset.evdel) resetEv();
        await loadJsop();
        renderJsop();
      } else if (x.status === 401) expire();
    }, 400);
};
$("#sopEdit").oninput = (e) => {
  const t = e.target;
  if (t.dataset.sj !== undefined) sopDraft[+t.dataset.sj].judul = t.value;
  if (t.dataset.si !== undefined) sopDraft[+t.dataset.si].isi = t.value;
  $("#sopOk").textContent = "";
};
$("#sopEdit").onclick = (e) => {
  const d = e.target.closest("[data-srdel]");
  if (d && sopDraft.length > 1) {
    sopDraft.splice(+d.dataset.srdel, 1);
    renderJsop();
  }
};
$("#sopAdd").onclick = () => {
  if (sopDraft.length < 8) {
    sopDraft.push({ judul: "", isi: "" });
    renderJsop();
  }
};
$("#sopSave").onclick = () => {
  $("#sopErr").textContent = "";
  $("#sopOk").textContent = "";
  if (sopDraft.some((s) => !s.judul.trim())) {
    $("#sopErr").textContent = "Setiap langkah harus punya judul.";
    return;
  }
  L(async () => {
    const x = await api("/api/ppkpt/sop", "POST", { steps: sopDraft, link: $("#sopLink").value.trim() });
    if (x.ok) $("#sopOk").textContent = "SOP tersimpan dan sudah tampil di halaman mahasiswa.";
    else if (x.status === 401) expire();
    else $("#sopErr").textContent = (x.data && x.data.error) || "Gagal menyimpan SOP.";
  }, 400);
};
L(async () => {
  const r = await api("/api/me");
  if (r.ok) {
    user = r.data.user;
    await landing();
  } else show("login");
}, 300);
