"""Membuat atau mengubah akun PPKPT.

Jalankan:  python buat_akun_ppkpt.py
(akan menanyakan nama, email kampus, dan password).
Kalau email sudah terdaftar, akun itu diubah menjadi PPKPT dan passwordnya diganti.
"""
import getpass
import sqlite3
import sys

from werkzeug.security import generate_password_hash

import app as A


def main():
    a = sys.argv[1:]
    name = a[0].strip() if len(a) > 0 else input("Nama lengkap: ").strip()
    email = (a[1] if len(a) > 1 else input("Email kampus (@itsb.ac.id): ")).strip().lower()
    if len(a) > 2:
        pw = a[2]
    else:
        pw = getpass.getpass("Password (min. 8 karakter): ")
        if pw != getpass.getpass("Ulangi password: "):
            sys.exit("Password tidak sama. Dibatalkan.")
    if not name or not A.ITSB.match(email):
        sys.exit("Nama wajib diisi dan email harus @itsb.ac.id.")
    if len(pw) < 8:
        sys.exit("Password minimal 8 karakter.")
    con = sqlite3.connect(A.DB_PATH)
    row = con.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
    if row:
        con.execute(
            "UPDATE users SET name=?, pw_hash=?, role='ppkpt' WHERE id=?",
            (name, generate_password_hash(pw), row[0]),
        )
        print("Akun yang sudah ada diubah menjadi PPKPT:", email)
    else:
        con.execute(
            "INSERT INTO users(name,email,pw_hash,role,created_at) VALUES(?,?,?,'ppkpt',?)",
            (name, email, generate_password_hash(pw), A.now_iso()),
        )
        print("Akun PPKPT dibuat:", email)
    con.commit()
    con.close()


if __name__ == "__main__":
    main()
